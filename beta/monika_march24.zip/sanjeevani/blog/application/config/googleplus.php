<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// server code
// $config['googleplus']['application_name'] = '';
// $config['googleplus']['client_id']        = '827389935885-7u36f8upvnekddp56i5ipqiu3u7njgbs.apps.googleusercontent.com';
// $config['googleplus']['client_secret']    = 'y6tsDHvlhgyb4kIA8uVhz61Y';
// $config['googleplus']['redirect_uri']     = 'http://localhost/ezsyexam/';
// $config['googleplus']['api_key']          = '';
// $config['googleplus']['scopes']           = array();



/* Local Code */

$config['googleplus']['application_name'] = '';
$config['googleplus']['client_id']        = '827389935885-7u36f8upvnekddp56i5ipqiu3u7njgbs.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'y6tsDHvlhgyb4kIA8uVhz61Y';
$config['googleplus']['redirect_uri']     = 'http://localhost/classified/';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

/* End Local Code */