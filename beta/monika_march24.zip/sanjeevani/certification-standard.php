<?php include("header.php"); ?>
      <head>
      <meta charset="utf-8" />
      <title>Certification Standards-Agrocent, Organic,ONECERT, USOCA</title>
      <meta name="description" content="Sanjeevani organics certification, agrofoods certification standards. Government is continuously changing its policies like NOPO to PGS">
      <meta name="keywords" content="Organics, India, Organic certification, aditi certification, Jaivik Bharat certification, onecert certification, usda organic certification, USOCA">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
      <meta property="og:site_name" content="sanjeevaniagrofoods.com" />
      <meta property="og:url" content="https://www.sanjeevaniagrofoods.com/" />
      <meta property="og:type" content="website" />
      <meta property="og:image" content="assets/img/logo.webp" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="https://www.sanjeevaniagrofoods.com/SAgrofoods" />
      <meta name="twitter:creator" content="Sanjeevani Organics" />
      <link rel="shortcut icon" href="images/ico/favicon.png">
      <link rel="canonical" href="certification-standard.php" />
   </head>
   <div class="rv-breadcrumb pt-120 pb-120">
        <div class="container">
            <h1 class="rv-breadcrumb__title">Certification Standards</h1>
            <ul class="rv-breadcrumb__nav d-flex justify-content-center">
                <li><a href="index.html"><i class="fa-solid fa-sharp fa-home"></i>Home</a></li>
                <li class="current-page"><span class="dvdr"> &#47;</span><span>Certification</span></li>
            </ul>
        </div>
    </div>

   <body>
      <section class="bg-light">
         <div class="container">
            <div class="row first-career">
               <h3>CERTIFICATION</h3>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/852XP2Kx/11.webp" width="125" height="125" alt="sanjeevani Organics Indian Organic Certification"></a>  </div>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/qqmL6Wjk/22.webp" width="125" height="125" alt="sanjeevani Organics USOCA NPOP NAB 0011 Certification"></a>  </div>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/05HXQJ37/33.webp" width="125" height="125" alt="Sanjeevani Organics Jaivik Bharat Certification"></a>  </div>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/8z3rfTGK/44.png" width="125" height="125" alt="Sanjeevani Organics USDA Organic Certification"></a>  </div>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/c47S8hNV/44.webp" width="125" height="125" alt="Sanjeevani organics Onecert organic certified"></a>  </div>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/PxdZT2TT/55.webp" width="125" height="125" alt="Sanjeevani organics Canada Organic Biologique Canada Certified"></a>  </div>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/D02tQkhH/66.webp" width="125" height="125" alt="Sanjeevani organics certified by agrocert quality with excellence"></a>  </div>
               <div class="col-md-3">    <a><img src="https://i.postimg.cc/Wbzys71G/77.webp" width="125" height="125" alt="Sanjeevani organics certified by aditi"></a>  </div>
               <div class="first-career">
                  <h3>Sanjeevani Certification</h3>
                  <p align="justify"> We are the only company in India, which is certified by America's - USDA international standards.. <a href="https://www.usda.gov/">(USDA)</a> international standards </p>
                  <p align="justify">Sanjeevani Organics is Organic Operator/Grower, Processor and Trader, hence has certified by Agricultural and Processed Food Products Export Development Authority <a href="https://apeda.gov.in/apedawebsite/">(APEDA)</a> for National Programme for Organic Production <a href="https://apeda.gov.in/apedawebsite/organic/index.htm">(NPOP)</a> & <a href="https://www.ams.usda.gov/about-ams/programs-offices/national-organic-program">(NOP)</a> program. Sanjeevani Organics is one of very few companies having EU certification for process products in India.</p> 
                    <li>Sanjeevani is ISO:22000 HACCP Company and has Food Safety and Standards Authority of India <a href="https://www.fssai.gov.in/">(FSSAI)</a> registration.</li>
                  <li>Presently holding the certifications: NPOP, National Organic Program <a href="https://www.ams.usda.gov/about-ams/programs-offices/national-organic-program">(NOP)</a>, Certificate of Recognition (COR), Hazard Analysis Critical Control Point <a href="https://www.google.com/search?q=HACCP&sca_esv=142620ecb81ebb8b&sca_upv=1&sxsrf=ACQVn09wmvNlGZkrbOrIiXh69VJgzLG4mw%3A1714383785828&source=hp&ei=qWsvZoDgL6Pe2roPiIGTqAU&iflsig=ANes7DEAAAAAZi95uf4MWUSfUTbOcOrm2nJP1OxzY77p&ved=0ahUKEwjA2L2kkeeFAxUjr1YBHYjABFUQ4dUDCBU&uact=5&oq=HACCP&gs_lp=Egdnd3Mtd2l6IgVIQUNDUDIKECMYgAQYJxiKBTINEAAYgAQYsQMYQxiKBTIFEAAYgAQyBRAAGIAEMg0QABiABBixAxgUGIcCMgUQABiABDINEAAYgAQYsQMYFBiHAjIFEAAYgAQyBRAAGIAEMgUQABiABEiWA1AAWABwAHgAkAEAmAGNAaABjQGqAQMwLjG4AQPIAQD4AQL4AQGYAgGgApMBmAMAkgcDMC4xoAf8BQ&sclient=gws-wiz">(HACCP)</a></li>
                  <li>Sanjeevani Farm Production: Uttarakhand State Organic Certification <a href="https://www.usoca.org/">(USOCA)</a></li>
                  <li>Sanjeevani Processing and <a href="https://www.barsanamagic.com/">(DAIRY Products)</a> : USOCA, ADITI,ONECERT, AGROCERT</li>
                  <script>
                     //** Add this Script to the Custom Head section in the Additional Footer HTML **//
                     $(document).ready(function() {
                     
                         function close_accordion_section() {
                             $('.accordion .accordion-section-title').removeClass('active');
                             $('.accordion .accordion-section-content').slideUp(300).removeClass('open');
                         }
                         $('.accordion-section-title').click(function(e) {
                             // Grab current anchor value
                             var currentAttrValue = $(this).attr('href');
                     
                             if($(e.target).is('.active')) {
                                 close_accordion_section();
                             } 
                             else {
                                 close_accordion_section();
                                 // Add active class to section title
                                 $(this).addClass('active');
                                 // Open up the hidden content panel
                                 $('.accordion ' + currentAttrValue).slideDown(300).addClass('open'); 
                             }
                             e.preventDefault();
                         });
                     });
                  </script>
               </div>
            </div>
      </section>
     
      
   </body>
   <?php include("footer.php"); ?>
</html>