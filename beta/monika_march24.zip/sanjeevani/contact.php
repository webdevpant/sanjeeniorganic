<?php include('header.php'); ?>


    <!-- BREADCRUMB STARTS HERE -->
    <div class="rv-breadcrumb pt-120 pb-120">
        <div class="container">
            <h1 class="rv-breadcrumb__title">Contact</h1>

            <ul class="rv-breadcrumb__nav d-flex justify-content-center">
                <li><a href="index.html"><i class="fa-solid fa-sharp fa-home"></i> Home</a></li>
                <li class="current-page"><span class="dvdr"> &#47;</span><span>Contact</span></li>
            </ul>
        </div>
    </div>
    <!-- BREADCRUMB ENDS HERE -->


    <!-- CONTACT SECTION START -->
    <section class="rv-2-contact rv-inner-contact rv-section-spacing" data-aos="fade-up">
        <div class="container">
            <div class="rv-inner-contact-info-cards">
                <div class="rv-inner-contact-info">
                    <div class="rv-inner-contact-info__heading">
                        <div class="rv-inner-contact-info__icon">
                            <i class="fa-regular fa-phone"></i>
                        </div>
                        <h5 class="rv-inner-contact-info__title">Contact Numbers</h5>
                    </div>

                    <div class="rv-inner-contact-info__bottom">
                        <ul class="rv-5-footer-timings">
                            <li><a href="tel:01354150929">0135-4150929</a></li>
                            <li><a href="tel:8791079305">+91-87910-79305</a></li>
                        </ul>
                    </div>
                </div>

                <div class="rv-inner-contact-info">
                    <div class="rv-inner-contact-info__heading">
                        <div class="rv-inner-contact-info__icon">
                            <i class="fa-regular fa-envelope"></i>
                        </div>
                        <h5 class="rv-inner-contact-info__title">Email Address</h5>
                    </div>

                    <div class="rv-inner-contact-info__bottom">
                        <ul class="rv-5-footer-timings">
                            <li><a href="mailto:info@sanjeevaniagrofoods.com">info@sanjeevaniagrofoods.com</a></li>
                            <li><a href="mailto:sales@sanjeevaniagrofoods.com">sales@sanjeevaniagrofoods.com</a></li>
                        </ul>
                    </div>
                </div>

                <div class="rv-inner-contact-info">
                    <div class="rv-inner-contact-info__heading">
                        <div class="rv-inner-contact-info__icon">
                            <i class="fa-regular fa-clock"></i>
                        </div>
                        <h5 class="rv-inner-contact-info__title">Hours of Operation</h5>
                    </div>

                    <div class="rv-inner-contact-info__bottom">
                        <ul class="rv-5-footer-timings">
                            <li>
                                <span class="key">Monday - Saturday : </span>
                                <span class="value">08:30 am - 06:00 pm</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row gy-3 gy-sm-4">
                <!-- contact form -->
                <div class="col-xxl-8 col-lg-7">
                    <div class="rv-2-contact__txt rv-inner-contact__txt">
                        <h3 class="rv-2-contact-form-title">Let's Connect.</h3>
                        <form action="#" class="rv-2-contact__form rv-inner-contact__form">
                            <div class="row">
                                <div class="col-sm-6">
                                    <input type="text" name="name" id="rv-2-contact-name" placeholder="Your Name">
                                </div>

                                <div class="col-sm-6">
                                    <input type="email" name="email" id="rv-2-contact-email" placeholder="Email">
                                </div>
                                <div class="col-12">
                                    <select name="subjects" id="rv-2-contact-subject">
                                        <option value="Selects Subject" hidden>Select Subject</option>
                                        <option value="Project Buy">Project Buy</option>
                                        <option value="Custom Project">Custom Project</option>
                                        <option value="Partnership Offer">Partnership Offer</option>
                                        <option value="others">Others</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <textarea name="message" id="rv-2-contact-message" placeholder="Message"></textarea>
                                </div>
                                <div class="col-12">
                                    <button type="submit">Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- map -->
                <div class="col-xxl-4 col-lg-5">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13783.104747927127!2d77.9812004!3d30.2719576!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39092be598fa3f23%3A0xcd86e88350fce78a!2sSanjeevani%20Agrofoods%20Private%20Limited!5e0!3m2!1sen!2sin!4v1711626683745!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </section>
    <!-- CONTACT SECTION END -->

<?php include('footer.php'); ?>